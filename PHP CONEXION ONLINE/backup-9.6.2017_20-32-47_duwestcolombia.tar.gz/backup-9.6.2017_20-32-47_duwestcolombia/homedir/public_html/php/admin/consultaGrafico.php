<?php 
session_start();
//validar si el usuario se Logeo, de lo contrario no lo deje ingresar
if(!$_SESSION)
{
	header("location:../ingreso.php");
}
require '../conexionbd.php';

$tipcliente=$_POST['usu'];

//echo'<script>alert("usuario " '.$tipcliente.')</script>';

/*switch ($tipcliente) {
    case 1:
*/
    $consultotal=$db->query("SELECT c.id_cliente, c.nom_cliente, c.tipo_cliente, cc.total_peconomico,cc.total_rpersonal FROM cliente c, cliente_calificacion cc Where c.id_cliente=cc.id_cliente and cc.id_usuario='$tipcliente'")or die($db->error);
    $resul = $consultotal ->fetch_assoc();
    $json=json_encode($resul);
    echo $json;
    //echo 'data:[';
    /*while ($resul = $consultotal ->fetch_array(MYSQLI_BOTH))
    {*/
        //echo'{x:-'.$resul['total_rpersonal'].', y:'.$resul['total_peconomico'].', name:"'.$resul['nom_cliente'].'", tcliente:"'.$resul['tipo_cliente'].'"},';

    //}
    //echo ']';
  /*  break;
    case 2:
    
    $consultotal=$db->query("SELECT c.id_cliente, c.nom_cliente, c.tipo_cliente, cc.total_peconomico,cc.total_rpersonal FROM cliente c, cliente_calificacion cc Where c.id_cliente=cc.id_cliente and cc.id_usuario='$usu' and c.tipo_cliente='Distribuidor'")or die($db->error);

    while ($resul = $consultotal ->fetch_array(MYSQLI_BOTH))
    {
        echo'{x:-'.$resul['total_rpersonal'].', y:'.$resul['total_peconomico'].', name:"'.$resul['nom_cliente'].'", tcliente:"'.$resul['tipo_cliente'].'"},';

    }

    break;
    case 3:
        $consultotal=$db->query("SELECT c.id_cliente, c.nom_cliente, c.tipo_cliente, cc.total_peconomico,cc.total_rpersonal FROM cliente c, cliente_calificacion cc Where c.id_cliente=cc.id_cliente and cc.id_usuario='$usu' and c.tipo_cliente='Agricultor'")or die($db->error);

        while ($resul = $consultotal ->fetch_array(MYSQLI_BOTH))
        {
            echo'{x:-'.$resul['total_rpersonal'].', y:'.$resul['total_peconomico'].', name:"'.$resul['nom_cliente'].'", tcliente:"'.$resul['tipo_cliente'].'"},';

        }
    break;
    }

*/

?>