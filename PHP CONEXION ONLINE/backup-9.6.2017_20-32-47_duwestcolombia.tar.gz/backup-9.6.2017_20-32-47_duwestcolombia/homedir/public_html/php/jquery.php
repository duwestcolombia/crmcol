<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<script src="http://code.jquery.com/jquery-3.1.0.min.js"></script>

	<script>
	/* Con esto probamos si funciona JQUERY
		$(document).ready(function (){
			alert("listos");
		})
*/
	$(document).on(ready,function(){
		$('div').css({
			'background-color:'
		});
	});
	
	</script>
	
</head>
<body>
<div class='midiv'>
	<article>
		<p>Primer enlace</p>
	</article>
</div>
<div>
	<article>
		<p>segundo enlace</p>

	</article>
</div>
	

</body>
</html>