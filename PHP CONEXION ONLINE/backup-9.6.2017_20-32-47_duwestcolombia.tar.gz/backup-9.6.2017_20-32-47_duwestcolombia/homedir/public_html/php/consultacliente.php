<?php 
session_start();
require 'conexionbd.php';
$id=$_POST["lst_tipusuario"];
$usu=$_SESSION['usuario_sesion'];

$consulta=$db ->query("SELECT 
cm.id_cliente,c.nom_cliente,c.tipo_cliente,z.nom_zona, m.nom_municipio,cm.hect_cliente,
cm.hectsemb_cliente,cm.tel_cliente,cm.fcumpleanos_cliente,cm.email_cliente,cm.direccion_cliente,cm.vtotalcompras_cliente 
FROM cliente_municipio cm, cliente c, zona z, municipio m
WHERE c.id_cliente='$id'
and cm.id_usuario= '$usu'
GROUP BY id_clientemunicipio") or die($db->error);
while ($consultausu = $consulta ->fetch_array(MYSQLI_BOTH))
{
	//echo '<input type="text" class="form-control" name="txtid" value='.$consultausu['id_cliente'].'> ';
echo '		<form method="POST">
			<div class="row bs-example">
				<div class="">
						<h3>Información del Cliente</h3>
						<hr class="linea-division">
						<div class="well center-block">
							<div class="col-md-2 inline-block">
								<label for="lblid">NIT/Cedula</label>
								<input type="text" class="form-control" name="txtid" value="'.$consultausu['id_cliente'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lblnombre">Nombre</label>
								<input type="text" class="form-control" name="txtnombre" value="'.$consultausu['nom_cliente'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lbltipo">Tipo</label>
								<input type="text" class="form-control" name="txttipo" value="'.$consultausu['tipo_cliente'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lbldepto">Departamento</label>
								<input type="text" class="form-control" name="txtzona" value="'.$consultausu['nom_zona'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lblmun">Municipio</label>
								<input type="text" class="form-control" name="txtmunicipio" value="'.$consultausu['nom_municipio'].'"> 
							</div>
							<br>
							<!--SEGUNDO BLOQUE INFO CLIENTE-->
							<div class="col-md-2 inline-block">
								<label for="lblhect">Cantidad Hectareas</label>
								<input type="text" class="form-control" name="txthect" value="'.$consultausu['hect_cliente'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lblhectsem">Cantidad Hectareas Sembradas</label>
								<input type="text" class="form-control" name="txthectsem" value="'.$consultausu['hectsemb_cliente'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lbltel">Télefono</label>
								<input type="text" class="form-control" name="txttelefono" value="'.$consultausu['tel_cliente'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lbldir">Dirección</label>
								<input type="text" class="form-control" name="txtdir" value="'.$consultausu['direccion_cliente'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lblemail">Correo Electronico</label>
								<input type="text" class="form-control" name="txtemail" value="'.$consultausu['email_cliente'].'"> 
							</div>
							<br>
							<!--TERCER BLOQUE INFO CLIENTE-->
							<div class="col-md-2 inline-block">
								<label for="lblfcumple">Fecha cumpleaños</label>
								<input type="text" class="form-control" name="txtfcumple" value="'.$consultausu['fcumpleanos_cliente'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="lbltotcompras">Valor total compras</label>
								<input type="text" class="form-control" name="txttotcompras" value="'.$consultausu['vtotalcompras_cliente'].'"> 
							</div>
							
						</div>
					</div>
				</div>

			</div>
';}

$consulcalificacion=$db->query("SELECT * from cliente_calificacion where id_cliente='$id' and id_usuario='$usu'");
while ($calif=$consulcalificacion->fetch_array(MYSQLI_BOTH)) {
echo		'<!-- Columna POTENCIAL ECONOMICO DE LA CUENTA-->
			<div class="container-fluid">
				<div class="row bs-example">
					
					<div class="">
						<h3>Potencial economico de la cuenta</h3>
						<hr class="linea-division">
						<div class="well center-block">
							<div class="col-lg-2 inline-block">
								<label for="tpeconomico">Tamaño</label>
								<input type="text" class="form-control" value="'.$calif['tamano_peconomico'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="crepeconomico">Crecimiento</label>
								<input type="text" class="form-control" value="'.$calif['crecimi_peconomico'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="fpotencialeconomico">Finanzas</label>
								<input type="text" class="form-control" value="'.$calif['finanza_peconomico'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="comppotencialeconomico">Competencia</label>
								<input type="text" class="form-control" value="'.$calif['compt_peconomico'].'"> 
							</div>
							<div class="col-md-2 inline-block">
								<label for="totalpeconomico">Total</label>
								<input type="text" class="form-control" value="'.$calif['total_peconomico'].'"> 
							</div>
						</div>
					</div>
				</div>

			</div>
			<!-- Columna RELACION PERSONAL NEGOCIOS-->
			<div class="container-fluid">
				<div class="row bs-example">
					<h3>Relacion personal de negocios</h3>
					<hr class="linea-division">
					<div class="well center-block">
						<div class="col-md-2 inline-block">
							<label for="conorpnegocios">Conocimiento</label>
							<input type="text" class="form-control" value="'.$calif['conoci_rpersonal'].'"> 
						</div>
						<div class="col-md-2 inline-block">
							<label for="resprpnegocios">Responsabilidad</label>
							<input type="text" class="form-control" value="'.$calif['resp_rpersonal'].'"> 
						</div>
						<div class="col-md-2 inline-block">
							<label for="ppsrpnegocio">PPS</label>
							<input type="text" class="form-control" value="'.$calif['pps_rpersonal'].'"> 
						</div>
						<div class="col-md-2 inline-block">
							<label for="actitudrpnegogio">Actitud</label>
							<input type="text" class="form-control" value="'.$calif['actitud_rpersonal'].'"> 
						</div>

						<div class="col-md-2 inline-block">
							<label for="totalpeconomico">Total</label>
							<input type="text" class="form-control" value="'.$calif['total_rpersonal'].'"> 
						</div>

					</div>	
				</div>
			</div>
	</form>		
';
}

 ?>