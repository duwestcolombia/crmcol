<html>
<head>
	<title></title>
	<script type="text/javascript" src="java.js"></script>
</head>
<body onload="depto();">

	<div id="listdepto"></div><br>

	<div id="listmun"></div>

</body>
</html>